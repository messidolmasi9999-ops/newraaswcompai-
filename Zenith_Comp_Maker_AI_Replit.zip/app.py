import os, uuid, subprocess, threading, json, time
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_from_directory
from werkzeug.utils import secure_filename

BASE = Path(__file__).resolve().parent
UPLOAD = BASE / "uploads"
OUTPUT = BASE / "outputs"
UPLOAD.mkdir(exist_ok=True); OUTPUT.mkdir(exist_ok=True)

app = Flask(__name__)
# Flask limiti 10 GB olarak ayarlı; Replit'in kendi proxy/depolama limitleri
# daha düşük olabilir. Büyük maç dosyaları için harici obje depolama gerekir.
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024 * 1024
jobs = {}

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload():
    f = request.files.get("video")
    if not f or not f.filename:
        return jsonify(error="Lütfen bir maç videosu seç."), 400
    name = secure_filename(f.filename)
    ext = Path(name).suffix.lower()
    if ext not in {".mp4", ".mov", ".mkv", ".avi", ".webm"}:
        return jsonify(error="Desteklenen formatlar: MP4, MOV, MKV, AVI, WEBM"), 400
    job_id = uuid.uuid4().hex[:12]
    path = UPLOAD / f"{job_id}{ext}"
    f.save(path)
    jobs[job_id] = {"status":"uploaded", "progress":0, "message":"Video yüklendi.", "clips":[], "video":str(path)}
    return jsonify(job_id=job_id, filename=name)

@app.route("/analyze", methods=["POST"])
def analyze():
    data = request.get_json(force=True)
    jid = data.get("job_id")
    if jid not in jobs: return jsonify(error="Video bulunamadı."), 404
    if jobs[jid]["status"] == "running": return jsonify(error="Analiz zaten sürüyor."), 409
    cfg = {
        "players": data.get("players", []),
        "detail": data.get("detail", "Detaylı"),
        "resolution": data.get("resolution", "1080p"),
        "fps": int(data.get("fps", 30))
    }
    jobs[jid].update(status="running", progress=1, message="Analiz hazırlanıyor...")
    threading.Thread(target=run_analysis, args=(jid,cfg), daemon=True).start()
    return jsonify(ok=True)

@app.route("/status/<jid>")
def status(jid):
    if jid not in jobs: return jsonify(error="İş bulunamadı."), 404
    j = jobs[jid]
    return jsonify(status=j["status"], progress=j["progress"], message=j["message"],
                   clips=j["clips"], error=j.get("error"))

@app.route("/download/<jid>/<clip>")
def download(jid, clip):
    if jid not in jobs: return "Not found", 404
    p = OUTPUT / clip
    if not p.exists() or p.parent != OUTPUT: return "Not found", 404
    return send_from_directory(OUTPUT, clip, as_attachment=True)

def run_analysis(jid, cfg):
    j = jobs[jid]
    try:
        import cv2
        from ultralytics import YOLO
        video = j["video"]
        cap = cv2.VideoCapture(video)
        if not cap.isOpened(): raise RuntimeError("Video açılamadı. Codec/format uyumsuz olabilir.")
        fps = cap.get(cv2.CAP_PROP_FPS) or 25
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        duration = total / fps if total else 0
        cap.release()
        j["message"] = "Oyuncular ve top algılanıyor (YOLOv8)..."
        model = YOLO("yolov8n.pt")  # İlk çalıştırmada model otomatik indirilir.
        # Tracking + basit hareket/olay adayları. Kesin gol/pas/şut sınıflandırması değildir.
        cap = cv2.VideoCapture(video)
        candidates = []
        last_centers = {}
        frame_no = 0
        stride = 2 if cfg["detail"] == "Detaylı" else (3 if cfg["detail"] == "Orta" else 5)
        while True:
            ok, frame = cap.read()
            if not ok: break
            if frame_no % stride == 0:
                results = model.track(frame, persist=True, classes=[0,32], conf=0.25, verbose=False)
                r = results[0]
                boxes = r.boxes
                if boxes is not None and boxes.id is not None:
                    ids = boxes.id.cpu().numpy().astype(int)
                    xy = boxes.xyxy.cpu().numpy()
                    cl = boxes.cls.cpu().numpy().astype(int)
                    for tid, box, cls in zip(ids,xy,cl):
                        if cls != 0: continue
                        cx,cy = (box[0]+box[2])/2,(box[1]+box[3])/2
                        old = last_centers.get(tid)
                        if old:
                            dist = ((cx-old[0])**2+(cy-old[1])**2)**0.5
                            # Aday hareket anları; hedef oyuncu ID seçimi arayüzde yapılır.
                            if dist > 22:
                                candidates.append((frame_no/fps, int(tid), min(dist/35,1.0)))
                        last_centers[tid]=(cx,cy)
            frame_no += 1
            if total:
                j["progress"] = min(75, int(frame_no/total*75))
                if frame_no % max(1,int(fps*10)) == 0:
                    j["message"] = f"Video taranıyor: %{j['progress']}"
        cap.release()
        # Arayüzde oyuncu seçimi yapılmadığından tüm izleme ID'leri yerine hareket yoğunluğu yüksek anları çıkarır.
        # Bu, hedef oyuncu doğrulaması için manuel kontrol gerektirir.
        selected = set(int(x) for x in cfg["players"] if str(x).isdigit())
        if selected:
            candidates = [x for x in candidates if x[1] in selected]
        candidates.sort(key=lambda x:x[2], reverse=True)
        # Yakın olayları birleştir; 5 sn öncesi ve 5 sn sonrası.
        chosen=[]
        for t,tid,score in candidates:
            if all(abs(t-x[0]) > 10 for x in chosen):
                chosen.append((t,tid,score))
            if len(chosen)>=80: break
        if not chosen and duration:
            chosen=[(min(duration/2,5),-1,0)]
        j["message"]="MP4 klipleri oluşturuluyor..."
        out=[]
        res={"720p":"1280:720","1080p":"1920:1080","4k":"3840:2160"}.get(cfg["resolution"],"1920:1080")
        for n,(t,tid,score) in enumerate(sorted(chosen),1):
            start=max(0,t-5); end=min(duration,t+5)
            if end<=start: continue
            fname=f"zenith_{jid}_{n:03d}.mp4"
            cmd=["ffmpeg","-y","-ss",str(start),"-i",video,"-t",str(end-start),
                 "-vf",f"scale={res}:force_original_aspect_ratio=decrease,pad={res}:(ow-iw)/2:(oh-ih)/2",
                 "-r",str(cfg["fps"]),"-c:v","libx264","-preset","veryfast","-crf","20","-c:a","aac","-movflags","+faststart",str(OUTPUT/fname)]
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
            out.append({"name":fname,"time":round(t,2),"player_id":tid,"duration":round(end-start,2),"score":round(score,2)})
            j["clips"]=out
            j["progress"]=75+int(n/max(1,len(chosen))*25)
        j.update(status="done",progress=100,message=f"Tamamlandı: {len(out)} klip oluşturuldu.")
    except Exception as e:
        j.update(status="error",error=str(e),message="Analiz sırasında hata oluştu.")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "3000")), debug=False)
