ZENITH COMP MAKER AI — KURULUM

Bu paket, bilgisayarında çalışan yerel bir web arayüzüdür. Python + YOLOv8 ile video karelerinde futbolcuları algılar/izler, hareket yoğunluğu yüksek aday anları çıkarır ve FFmpeg ile MP4 klip üretir.

ÖNEMLİ SINIRLAR
- Bu sürüm gerçek bir çalışan başlangıç uygulamasıdır; ancak gol, şut ve uzun pası kusursuz tanıyan özel eğitilmiş bir futbol modeli değildir.
- Görüntüden tek başına doğru oyuncuyu her pozisyonda ayırmak garanti edilemez. Takip ID'leri karışabilir; üretilen klipleri kontrol et.
- Arayüzde girilen oyuncu ID'leri, YOLO takip ID'leriyle eşleşirse filtre uygular. Oyuncu ID'lerini tespit etmek için önce kısa bir test videosu kullan.
- İlk analizde yolov8n.pt modeli internetten otomatik indirilir. Sonraki kullanımlarda yerelde saklanır.
- 4K çıktı, kaynak video 4K değilse gerçek ayrıntı eklemez; yalnızca ölçeklendirir.
- 10 GB yükleme limiti ayarlıdır. Sunucunun disk alanı ve RAM'i yeterli olmalıdır.

GEREKENLER
1) Python 3.10 veya 3.11
2) FFmpeg kurulu ve PATH'e ekli olmalı.
3) NVIDIA GPU önerilir; CPU'da analiz çok yavaş olabilir.

WINDOWS
1) ZIP'i klasöre çıkar.
2) Klasörün içinde adres çubuğuna cmd yazıp Enter'a bas.
3) Şunları çalıştır:
   py -m venv .venv
   .venv\\Scripts\\activate
   pip install -r requirements.txt
   py app.py
4) Tarayıcıda http://127.0.0.1:5000 aç.

LINUX / MAC
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
Ardından http://127.0.0.1:5000

NOT: 10 GB dosyalar için yeterli boş disk alanı ve stabil bağlantı gerekir. Video taraması uzun sürebilir.
