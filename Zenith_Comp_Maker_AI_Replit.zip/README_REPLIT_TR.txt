
ZENITH COMP MAKER AI — REPLIT SÜRÜMÜ

REPLIT'TE AÇMA
1. Replit hesabına gir ve Create Repl / Import from ZIP seçeneği varsa ZIP'i içe aktar.
   Alternatif: Yeni Python Repl oluştur, ZIP içeriğini Files bölümüne yükleyip çıkar.
2. .replit, replit.nix, app.py, requirements.txt ve templates/static klasörleri aynı ana dizinde olmalı.
3. Shell bölümünde:
   pip install -r requirements.txt
4. Run düğmesine bas. Uygulama PORT ortam değişkenini kullanır ve 0.0.0.0 adresinde dinler.
5. İlk analizde YOLOv8n modeli indirilir; ilk açılış/analiz uzun sürebilir.

ÖNEMLİ REPLIT SINIRLAMALARI
- Flask uygulamasının dosya limiti 10 GB ayarlıdır; bu, Replit'in 10 GB yüklemeyi kabul edeceği anlamına gelmez.
  Replit'in plan, proxy, depolama ve çalışma zamanı limitleri dosya yüklemeyi veya uzun analizi engelleyebilir.
- Ücretsiz/uykuya geçen çalışma alanlarında uzun video analizi kesilebilir.
- Replit'in geçici dosya alanı kalıcı depolama garantisi değildir. Video/çıktılar çalışma alanı sıfırlanırsa kaybolabilir.
- 10 GB tam maçları güvenilir biçimde işlemek için kalıcı disk/obje depolama ve uzun süre çalışan GPU/CPU sunucusu gerekir.
- Bu kod YOLO ile kişi algılama ve hareket adayı çıkarır. Gol, şut, uzun pası futbol bilgisiyle kesin sınıflandırmaz.
- Oyuncu ID'leri takip algoritmasının ürettiği geçici ID'lerdir; oyuncu kimliğini garanti etmez. Yanlış oyuncuyu hiç almama garantisi yoktur.
- 4K seçeneği videoyu 4K boyutuna ölçekler; kaynakta olmayan gerçek detay oluşturmaz.

Bu ZIP, Replit'te başlatılabilir hâle getirilmiştir; platform kaynak limitleri ve futbol olay tespit doğruluğu ayrıca geliştirilmelidir.
